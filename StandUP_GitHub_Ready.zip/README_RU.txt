StandUP — готовый Android-проект для сборки APK через GitHub Actions

Содержимое:
- app/src/main/assets/index.html — локальная версия StandUP, включённая внутрь приложения;
- app/src/main/res — иконки приложения;
- app/src/main/java — Android WebView-оболочка;
- .github/workflows/main.yml — автоматическая сборка APK.

ВАЖНО: APK не является ZIP-файлом. Его нужно собрать через GitHub Actions.

Если загружаешь этот ZIP в репозиторий как StandUP_GitHub_Ready.zip:
1. В корне репозитория должен быть файл StandUP_GitHub_Ready.zip.
2. Содержимое .github/workflows/main.yml из этого проекта должно быть сохранено в репозитории по пути .github/workflows/main.yml.
3. Открой Actions → Build StandUP APK → Run workflow.
4. После зелёного Success открой запуск и скачай артефакт StandUP-APK.
5. Внутри артефакта находится StandUP.apk.

Workflow также умеет собирать ранее загруженный StandUP_Android_Project.zip.
Он сам находит settings.gradle во вложенной папке и не требует gradlew внутри ZIP.
